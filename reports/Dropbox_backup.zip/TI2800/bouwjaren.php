<?php
// Database gegevens
$db['host']	= 'localhost:3307';
$db['username'] = 'root';
$db['password'] = 'pass';
$db['name'] = 'dataset';


// Als de database is ingesteld, verbinding maken
mysql_connect($db['host'],$db['username'],$db['password']);
mysql_select_db($db['name']);

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><head></head><body>';

ob_start();

echo 'Kijken welke monumenten bouwjaren in de description hebben in de database...</br>';
flush();
ob_flush();

$sSql = "select id_monument, title, description from monument where description regexp '[0-2]{1}[0-9]{3}';";
$aRows = mysql_query($sSql) or die($sSql.'</br>'.mysql_error());

echo 'Bouwjaar filteren uit de description per monument...</br>';
flush();
ob_flush();

$aMonumenten = array();
$aBouwjaren = array();
while($aRow = mysql_fetch_array($aRows)) {
	preg_match('/([0-2]{1}[0-9]{3})/',$aRow['description'], $aMatches);
	if($aMatches[0] === 0) continue;
	$aMonumenten[] = $aRow['id_monument'];
	$aBouwjaren[] = $aMatches[0];
}
echo 'Bouwjaren zijn opgezocht uit de description!...</br>';
echo 'Terugpompen naar de database...</br>';

flush();
ob_flush();

$sSql = 'update monument set bouwjaar = CASE';
foreach($aMonumenten as $iKey=>$iMonument) {
	$sSql.=' when id_monument = '.$iMonument.' then '.$aBouwjaren[$iKey];
}
$sSql.= ' else bouwjaar end where id_monument in ('.implode(',',$aMonumenten).')';

mysql_query($sSql) or die($sSql.'</br>'.mysql_error());

echo 'KLAAR! Er zijn bouwjaren toegevoegd aan '.count($aMonumenten).' monumenten.';
echo '</body></html>';

?>